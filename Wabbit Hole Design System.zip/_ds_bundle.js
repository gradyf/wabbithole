/* @ds-bundle: {"format":4,"namespace":"WabbitHoleDesignSystem_ca83f3","components":[{"name":"Button","sourcePath":"components/actions/Button.jsx"},{"name":"IconButton","sourcePath":"components/actions/IconButton.jsx"},{"name":"ArticleProse","sourcePath":"components/article/ArticleProse.jsx"},{"name":"ArticleCard","sourcePath":"components/card/ArticleCard.jsx"},{"name":"AttributionFooter","sourcePath":"components/card/AttributionFooter.jsx"},{"name":"CardTab","sourcePath":"components/card/CardTab.jsx"},{"name":"DepthBadge","sourcePath":"components/chrome/DepthBadge.jsx"},{"name":"TopBar","sourcePath":"components/chrome/TopBar.jsx"},{"name":"Wordmark","sourcePath":"components/chrome/Wordmark.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Icon","sourcePath":"components/icons/Icon.jsx"},{"name":"Overlay","sourcePath":"components/panels/Overlay.jsx"},{"name":"TrailPanel","sourcePath":"components/panels/TrailPanel.jsx"},{"name":"SearchField","sourcePath":"components/search/SearchField.jsx"}],"sourceHashes":{"components/actions/Button.jsx":"4207c61bb264","components/actions/IconButton.jsx":"4c2d579f8b36","components/article/ArticleProse.jsx":"00b3f1f167c6","components/card/ArticleCard.jsx":"ae284b8da16c","components/card/AttributionFooter.jsx":"802af72fe531","components/card/CardTab.jsx":"07c97b4cb45f","components/chrome/DepthBadge.jsx":"7969c6dcfe20","components/chrome/TopBar.jsx":"acba7ce558d2","components/chrome/Wordmark.jsx":"3e11641c5d4f","components/feedback/Toast.jsx":"feb168216a05","components/icons/Icon.jsx":"edaeeff0ee3c","components/panels/Overlay.jsx":"8893ddb89773","components/panels/TrailPanel.jsx":"c346df24e984","components/search/SearchField.jsx":"75a2f22ddba7","ui_kits/app/EntryScreen.jsx":"b5827c9447b8","ui_kits/app/StackScreen.jsx":"b5a3ffc8f6ed","ui_kits/app/articles.js":"69322f154dce"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.WabbitHoleDesignSystem_ca83f3 = window.WabbitHoleDesignSystem_ca83f3 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/actions/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Chrome button. Solid = the rare primary action; soft = raised paper chip;
 *  ghost = quiet top-bar control. */
function Button({
  variant = "solid",
  size = "md",
  icon,
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: "wh-btn",
    "data-variant": variant,
    "data-size": size
  }, rest), icon ? /*#__PURE__*/React.createElement("span", {
    className: "wh-icon",
    "data-name": icon,
    "aria-hidden": "true"
  }) : null, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/Button.jsx", error: String((e && e.message) || e) }); }

// components/actions/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Square icon-only control. Always give it a label for assistive tech. */
function IconButton({
  icon,
  label,
  size = "md",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: "wh-iconbtn",
    "data-size": size,
    "aria-label": label,
    title: label
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "wh-icon",
    "data-name": icon,
    "aria-hidden": "true"
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/article/ArticleProse.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Wrapper that styles encyclopedia HTML (.wh-prose scope). Pass fetched
 *  markup via `html`, or compose children for curated content. */
function ArticleProse({
  html,
  children,
  ...rest
}) {
  if (html !== undefined) {
    return /*#__PURE__*/React.createElement("div", _extends({
      className: "wh-prose",
      dangerouslySetInnerHTML: {
        __html: html
      }
    }, rest));
  }
  return /*#__PURE__*/React.createElement("div", _extends({
    className: "wh-prose"
  }, rest), children);
}
Object.assign(__ds_scope, { ArticleProse });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/article/ArticleProse.jsx", error: String((e && e.message) || e) }); }

// components/card/AttributionFooter.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Required licensing line at the end of every card's scroll content. */
function AttributionFooter({
  title,
  href,
  ...rest
}) {
  const src = href || `https://en.wikipedia.org/wiki/${encodeURIComponent(String(title || "").replace(/ /g, "_"))}`;
  return /*#__PURE__*/React.createElement("footer", _extends({
    className: "wh-attrib"
  }, rest), "Content from the Wikipedia article", " ", /*#__PURE__*/React.createElement("a", {
    href: src,
    target: "_blank",
    rel: "noopener"
  }, title), ", reformatted for this reader with some elements omitted. Text is available under", " ", /*#__PURE__*/React.createElement("a", {
    href: "https://creativecommons.org/licenses/by-sa/4.0/",
    target: "_blank",
    rel: "noopener"
  }, "CC BY-SA 4.0"), "; images are licensed individually.");
}
Object.assign(__ds_scope, { AttributionFooter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/card/AttributionFooter.jsx", error: String((e && e.message) || e) }); }

// components/card/CardTab.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Card header strip — always visible, even buried. Buried tabs are a single
 *  click target that reopens the card; the top card's tab is inert. */
function CardTab({
  index,
  title,
  subtitle,
  buried,
  onClick,
  ...rest
}) {
  const content = /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: "wh-tab-num"
  }, index), /*#__PURE__*/React.createElement("span", {
    className: "wh-tab-title"
  }, title), subtitle ? /*#__PURE__*/React.createElement("span", {
    className: "wh-tab-sub"
  }, subtitle) : null);
  if (buried) {
    return /*#__PURE__*/React.createElement("button", _extends({
      type: "button",
      className: "wh-tab",
      "data-buried": "",
      onClick: onClick,
      "aria-label": `Return to ${title} — card ${index}`
    }, rest), content);
  }
  return /*#__PURE__*/React.createElement("div", _extends({
    className: "wh-tab"
  }, rest), content);
}
Object.assign(__ds_scope, { CardTab });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/card/CardTab.jsx", error: String((e && e.message) || e) }); }

// components/card/ArticleCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function LoadingBody() {
  const bar = (w, h = 14, mb = 12) => /*#__PURE__*/React.createElement("div", {
    className: "wh-skel",
    style: {
      width: w,
      height: h,
      marginBottom: mb
    }
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--measure-prose)",
      margin: "0 auto"
    },
    "aria-hidden": "true"
  }, bar("46%", 30, 22), bar("30%", 12, 28), bar("100%"), bar("97%"), bar("99%"), bar("62%", 14, 28), bar("100%"), bar("94%"), bar("42%"));
}

/** An article as a card: tab strip, independently scrolling body, required
 *  attribution footer. `state` renders the full lifecycle. */
function ArticleCard({
  index,
  title,
  subtitle,
  state = "active",
  onTabClick,
  onRetry,
  errorMessage,
  entering,
  sourceHref,
  children,
  className,
  ...rest
}) {
  const buried = state === "buried";
  let body;
  if (state === "loading") {
    body = /*#__PURE__*/React.createElement(LoadingBody, null);
  } else if (state === "error") {
    body = /*#__PURE__*/React.createElement("div", {
      className: "wh-note"
    }, /*#__PURE__*/React.createElement("span", {
      className: "wh-icon",
      "data-name": "rotate-ccw",
      "aria-hidden": "true"
    }), /*#__PURE__*/React.createElement("p", {
      className: "wh-note-title"
    }, "That didn't load"), /*#__PURE__*/React.createElement("p", {
      className: "wh-note-body"
    }, errorMessage || "Something went wrong on the way down. Wikipedia may be busy."), /*#__PURE__*/React.createElement("button", {
      type: "button",
      className: "wh-btn",
      "data-size": "sm",
      onClick: onRetry
    }, "Try again"));
  } else if (state === "resting") {
    body = /*#__PURE__*/React.createElement("div", {
      className: "wh-note"
    }, /*#__PURE__*/React.createElement("span", {
      className: "wh-icon",
      "data-name": "layers",
      "aria-hidden": "true"
    }), /*#__PURE__*/React.createElement("p", {
      className: "wh-note-title"
    }, "Resting"), /*#__PURE__*/React.createElement("p", {
      className: "wh-note-body"
    }, "This card set down its content to save memory. Reopen it and everything comes right back."));
  } else {
    body = /*#__PURE__*/React.createElement(React.Fragment, null, children, title ? /*#__PURE__*/React.createElement(__ds_scope.AttributionFooter, {
      title: title,
      href: sourceHref
    }) : null);
  }
  return /*#__PURE__*/React.createElement("section", _extends({
    className: ["wh-card", entering ? "wh-card-enter" : "", className || ""].join(" ").trim(),
    "data-state": state,
    "aria-label": `${title} — card ${index}`
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.CardTab, {
    index: index,
    title: title,
    subtitle: subtitle,
    buried: buried,
    onClick: onTabClick
  }), /*#__PURE__*/React.createElement("div", _extends({
    className: "wh-card-body"
  }, buried ? {
    inert: ""
  } : {}), body));
}
Object.assign(__ds_scope, { ArticleCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/card/ArticleCard.jsx", error: String((e && e.message) || e) }); }

// components/chrome/DepthBadge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** "1 card" / "N deep" chip. Hide on narrow viewports. */
function DepthBadge({
  count = 1,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    className: "wh-depth"
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "wh-icon",
    "data-name": "layers",
    "aria-hidden": "true"
  }), count === 1 ? "1 card" : `${count} deep`);
}
Object.assign(__ds_scope, { DepthBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/chrome/DepthBadge.jsx", error: String((e && e.message) || e) }); }

// components/chrome/Wordmark.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Type-only wordmark — no logo mark exists (see readme). Lowercase always. */
function Wordmark({
  size = "bar",
  onClick,
  style,
  ...rest
}) {
  const El = onClick ? "button" : "span";
  return /*#__PURE__*/React.createElement(El, _extends({
    className: "wh-wordmark",
    "data-size": size === "hero" ? "hero" : undefined,
    onClick: onClick,
    title: onClick ? "Start over" : undefined,
    style: style
  }, rest), "wabbit hole");
}
Object.assign(__ds_scope, { Wordmark });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/chrome/Wordmark.jsx", error: String((e && e.message) || e) }); }

// components/chrome/TopBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Persistent app bar while cards are open. Back hides at depth 1;
 *  the wordmark is "start over". */
function TopBar({
  depth = 1,
  onBack,
  onTrail,
  onShare,
  onHome,
  hideDepth,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("header", _extends({
    className: "wh-topbar"
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Wordmark, {
    onClick: onHome
  }), /*#__PURE__*/React.createElement("div", {
    className: "wh-topbar-spacer"
  }), depth > 1 ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "wh-btn",
    "data-variant": "ghost",
    onClick: onBack
  }, /*#__PURE__*/React.createElement("span", {
    className: "wh-icon",
    "data-name": "arrow-left",
    "aria-hidden": "true"
  }), "Back") : null, hideDepth ? null : /*#__PURE__*/React.createElement(__ds_scope.DepthBadge, {
    count: depth
  }), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "wh-btn",
    "data-variant": "ghost",
    onClick: onTrail
  }, /*#__PURE__*/React.createElement("span", {
    className: "wh-icon",
    "data-name": "list",
    "aria-hidden": "true"
  }), "Trail"), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "wh-btn",
    "data-variant": "soft",
    onClick: onShare
  }, /*#__PURE__*/React.createElement("span", {
    className: "wh-icon",
    "data-name": "link",
    "aria-hidden": "true"
  }), "Share"));
}
Object.assign(__ds_scope, { TopBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/chrome/TopBar.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Self-dismissing status pill, bottom-center. Render conditionally;
 *  ~3.5s lifetime is the caller's job. */
function Toast({
  children,
  inline,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: "wh-toast",
    role: "status",
    style: inline ? {
      position: "static",
      transform: "none",
      animation: "none",
      width: "max-content",
      ...style
    } : style
  }, rest), children);
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/icons/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Glyph from the copied Lucide set (assets/icons), masked to currentColor. */
function Icon({
  name,
  size = 16,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    className: "wh-icon",
    "data-name": name,
    style: {
      width: size,
      height: size,
      ...style
    },
    "aria-hidden": "true"
  }, rest));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/icons/Icon.jsx", error: String((e && e.message) || e) }); }

// components/panels/Overlay.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Scrim + floating panel for Trail and About. Escape and scrim-click close. */
function Overlay({
  open = true,
  onClose,
  title,
  side = "right",
  children,
  footer,
  ...rest
}) {
  React.useEffect(() => {
    if (!open) return undefined;
    const onKey = e => {
      if (e.key === "Escape" && onClose) onClose();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "wh-overlay",
    onClick: e => {
      if (e.target === e.currentTarget && onClose) onClose();
    }
  }, /*#__PURE__*/React.createElement("div", _extends({
    className: "wh-panel",
    "data-side": side,
    role: "dialog",
    "aria-modal": "true",
    "aria-label": title
  }, rest), /*#__PURE__*/React.createElement("div", {
    className: "wh-panel-head"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "wh-panel-title"
  }, title), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "wh-iconbtn",
    "data-size": "sm",
    "aria-label": "Close",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("span", {
    className: "wh-icon",
    "data-name": "x",
    "aria-hidden": "true"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "wh-panel-body",
    "data-pad": side === "center" ? "" : undefined
  }, children), footer ? /*#__PURE__*/React.createElement("div", {
    className: "wh-panel-foot"
  }, footer) : null));
}
Object.assign(__ds_scope, { Overlay });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/panels/Overlay.jsx", error: String((e && e.message) || e) }); }

// components/panels/TrailPanel.jsx
try { (() => {
/** The trail as a docked, collapsible left sidebar: every card in order;
 *  selecting one reopens it. Collapse with the header control or the top
 *  bar's Trail button. */
function TrailPanel({
  open = true,
  entries = [],
  currentIndex,
  onSelect,
  onExport,
  onClose
}) {
  const count = entries.length;
  return /*#__PURE__*/React.createElement("aside", {
    className: "wh-sidebar",
    "data-collapsed": open ? undefined : "",
    "aria-label": "Trail",
    "aria-hidden": !open
  }, /*#__PURE__*/React.createElement("div", {
    className: "wh-sidebar-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wh-sidebar-head"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "wh-panel-title"
  }, "Trail"), onClose ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "wh-iconbtn",
    "data-size": "sm",
    "aria-label": "Collapse trail",
    title: "Collapse trail",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("span", {
    className: "wh-icon",
    "data-name": "arrow-left",
    "aria-hidden": "true"
  })) : null), /*#__PURE__*/React.createElement("div", {
    className: "wh-sidebar-body",
    role: "list"
  }, entries.map((entry, i) => /*#__PURE__*/React.createElement("button", {
    type: "button",
    role: "listitem",
    key: `${entry.title}-${i}`,
    className: "wh-trail-item",
    "data-current": i === currentIndex ? "" : undefined,
    onClick: () => onSelect && onSelect(i)
  }, /*#__PURE__*/React.createElement("span", {
    className: "wh-trail-num"
  }, i + 1), /*#__PURE__*/React.createElement("span", {
    className: "wh-trail-text"
  }, /*#__PURE__*/React.createElement("span", {
    className: "wh-trail-title"
  }, entry.title), entry.subtitle ? /*#__PURE__*/React.createElement("span", {
    className: "wh-trail-sub"
  }, entry.subtitle) : null), i === currentIndex ? null : /*#__PURE__*/React.createElement("span", {
    className: "wh-icon",
    "data-name": "chevron-right",
    "aria-hidden": "true",
    style: {
      alignSelf: "center",
      color: "var(--text-faint)",
      width: 14,
      height: 14
    }
  })))), /*#__PURE__*/React.createElement("div", {
    className: "wh-sidebar-foot"
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "wh-btn",
    "data-variant": "soft",
    "data-size": "sm",
    onClick: onExport
  }, /*#__PURE__*/React.createElement("span", {
    className: "wh-icon",
    "data-name": "download",
    "aria-hidden": "true"
  }), "Export Markdown"), /*#__PURE__*/React.createElement("div", {
    className: "wh-topbar-spacer"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-label)",
      color: "var(--text-faint)",
      fontVariantNumeric: "tabular-nums"
    }
  }, count === 1 ? "1 card" : `${count} cards`))));
}
Object.assign(__ds_scope, { TrailPanel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/panels/TrailPanel.jsx", error: String((e && e.message) || e) }); }

// components/search/SearchField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Article search with live autocomplete. Handles its own keyboard loop
 *  (arrows / Enter / Escape) and value state unless controlled. */
function SearchField({
  placeholder = "start anywhere…",
  size = "md",
  value,
  onChange,
  results = [],
  onSelect,
  onDismiss,
  autoFocus,
  ...rest
}) {
  const [innerValue, setInnerValue] = React.useState("");
  const [active, setActive] = React.useState(-1);
  const [closed, setClosed] = React.useState(false);
  const val = value !== undefined ? value : innerValue;
  const open = !closed && val.trim().length > 0 && results.length > 0;
  const setVal = v => {
    if (value === undefined) setInnerValue(v);
    if (onChange) onChange(v);
    setClosed(false);
    setActive(-1);
  };
  const pick = i => {
    const r = results[i] || results[0];
    if (r && onSelect) onSelect(r);
  };
  const onKeyDown = e => {
    if (e.key === "ArrowDown" && open) {
      e.preventDefault();
      setActive(a => (a + 1) % results.length);
    } else if (e.key === "ArrowUp" && open) {
      e.preventDefault();
      setActive(a => a <= 0 ? results.length - 1 : a - 1);
    } else if (e.key === "Enter" && open) {
      e.preventDefault();
      pick(active === -1 ? 0 : active);
    } else if (e.key === "Escape") {
      setClosed(true);
      setActive(-1);
      if (onDismiss) onDismiss();
    }
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    className: "wh-search",
    "data-size": size
  }, rest), /*#__PURE__*/React.createElement("div", {
    className: "wh-search-box"
  }, /*#__PURE__*/React.createElement("span", {
    className: "wh-icon",
    "data-name": "search",
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("input", {
    type: "text",
    role: "combobox",
    "aria-expanded": open,
    "aria-autocomplete": "list",
    placeholder: placeholder,
    value: val,
    autoFocus: autoFocus,
    onChange: e => setVal(e.target.value),
    onKeyDown: onKeyDown
  })), open ? /*#__PURE__*/React.createElement("div", {
    className: "wh-search-pop",
    role: "listbox"
  }, results.slice(0, 6).map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: r.title,
    className: "wh-result",
    role: "option",
    "aria-selected": i === active,
    "data-active": i === active ? "" : undefined,
    onMouseEnter: () => setActive(i),
    onMouseDown: e => e.preventDefault(),
    onClick: () => pick(i)
  }, /*#__PURE__*/React.createElement("span", {
    className: "wh-result-title"
  }, r.title), /*#__PURE__*/React.createElement("span", {
    className: "wh-result-desc"
  }, r.description), i === active ? /*#__PURE__*/React.createElement("span", {
    className: "wh-kbd"
  }, "\u21B5") : null))) : null);
}
Object.assign(__ds_scope, { SearchField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/search/SearchField.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/EntryScreen.jsx
try { (() => {
/* Entry screen — shown when no cards are open. */
const {
  SearchField,
  Button,
  Wordmark
} = window.WabbitHoleDesignSystem_ca83f3;
function WHEntryScreen({
  onOpen,
  onRandom,
  onAbout
}) {
  const [q, setQ] = React.useState("");
  const results = q.trim() ? window.WH_DATA.searchPool.filter(r => r.title.toLowerCase().startsWith(q.trim().toLowerCase())) : [];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: "100vh",
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      padding: "0 24px 8vh"
    }
  }, /*#__PURE__*/React.createElement(Wordmark, {
    size: "hero"
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-serif)",
      fontSize: "var(--text-lg)",
      color: "var(--text-secondary)",
      margin: "14px 0 40px",
      textAlign: "center",
      maxWidth: 440,
      lineHeight: 1.5,
      textWrap: "balance"
    }
  }, "Follow one link. Then another. The stack is the story of how you got here."), /*#__PURE__*/React.createElement("div", {
    style: {
      width: "min(560px, 100%)"
    }
  }, /*#__PURE__*/React.createElement(SearchField, {
    size: "lg",
    value: q,
    onChange: setQ,
    results: results,
    onSelect: r => onOpen(r.title),
    autoFocus: true
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 20
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    icon: "shuffle",
    onClick: onRandom
  }, "or fall in somewhere random \u2193"))), /*#__PURE__*/React.createElement("footer", {
    style: {
      padding: "16px 24px 20px",
      textAlign: "center",
      fontSize: "var(--text-caption)",
      color: "var(--text-faint)"
    }
  }, "Article text from", " ", /*#__PURE__*/React.createElement("a", {
    href: "https://en.wikipedia.org",
    target: "_blank",
    rel: "noopener",
    style: {
      color: "var(--text-secondary)"
    }
  }, "Wikipedia"), ", reformatted, under", " ", /*#__PURE__*/React.createElement("a", {
    href: "https://creativecommons.org/licenses/by-sa/4.0/",
    target: "_blank",
    rel: "noopener",
    style: {
      color: "var(--text-secondary)"
    }
  }, "CC BY-SA 4.0"), ". Not affiliated with the Wikimedia Foundation. \xB7", " ", /*#__PURE__*/React.createElement("a", {
    href: "#about",
    onClick: e => {
      e.preventDefault();
      onAbout();
    },
    style: {
      color: "var(--text-secondary)"
    }
  }, "About")));
}
window.WHEntryScreen = WHEntryScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/EntryScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/StackScreen.jsx
try { (() => {
/* Stack screen — the cascading card stack on the desk. */
const {
  ArticleCard,
  ArticleProse
} = window.WabbitHoleDesignSystem_ca83f3;
const VISIBLE_CARDS = 5; /* older cards live in the Trail panel */

function WHArticleContent({
  title,
  subtitle,
  html,
  isTop,
  onLink,
  onDeadLink
}) {
  const titleRef = React.useRef(null);
  React.useEffect(() => {
    if (isTop && titleRef.current) titleRef.current.focus({
      preventScroll: true
    });
  }, [isTop]);
  const handleClick = e => {
    const a = e.target.closest ? e.target.closest("a") : null;
    if (!a) return;
    if (a.dataset.article !== undefined) {
      e.preventDefault();
      onLink(a.dataset.article);
    } else if (a.dataset.dead !== undefined) {
      e.preventDefault();
      onDeadLink(a.textContent);
    } else if (a.dataset.ref !== undefined) {
      e.preventDefault();
      const body = a.closest(".wh-card-body");
      const li = body && body.querySelector("#" + a.dataset.ref);
      if (!body || !li) return;
      const top = li.getBoundingClientRect().top - body.getBoundingClientRect().top + body.scrollTop - 56;
      const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      body.scrollTo({
        top,
        behavior: reduced ? "auto" : "smooth"
      });
      li.classList.remove("wh-flash");
      void li.offsetWidth;
      li.classList.add("wh-flash");
    }
  };
  return /*#__PURE__*/React.createElement("div", {
    onClick: handleClick
  }, /*#__PURE__*/React.createElement("h1", {
    className: "wh-card-title",
    tabIndex: -1,
    ref: titleRef,
    style: {
      outline: "none"
    }
  }, title), subtitle ? /*#__PURE__*/React.createElement("p", {
    className: "wh-card-title-sub"
  }, subtitle) : null, /*#__PURE__*/React.createElement(ArticleProse, {
    html: html
  }));
}
function WHStackScreen({
  trail,
  onLink,
  onReopen,
  onDeadLink
}) {
  const start = Math.max(0, trail.length - VISIBLE_CARDS);
  const visible = trail.slice(start);
  const m = visible.length;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      position: "relative",
      overflow: "hidden"
    },
    "data-screen-label": "Stack"
  }, visible.map((entry, j) => {
    const i = start + j; /* index in the full trail */
    const isTop = j === m - 1;
    const data = window.WH_DATA.articles[entry.title] || {};
    const state = isTop ? entry.loading ? "loading" : "active" : "buried";
    const inset = (m - 1 - j) * 14;
    return /*#__PURE__*/React.createElement("div", {
      key: entry.title,
      style: {
        position: "absolute",
        top: 6 + j * 40,
        bottom: 0,
        left: "50%",
        transform: "translateX(-50%)",
        width: `min(calc(var(--card-width) - ${inset}px), calc(100% - 64px - ${inset}px))`,
        zIndex: j + 1
      }
    }, /*#__PURE__*/React.createElement(ArticleCard, {
      index: i + 1,
      title: entry.title,
      subtitle: data.subtitle,
      state: state,
      entering: isTop && entry.entered,
      onTabClick: () => onReopen(i),
      style: {
        height: "100%"
      }
    }, state === "active" ? /*#__PURE__*/React.createElement(WHArticleContent, {
      title: entry.title,
      subtitle: data.subtitle,
      html: data.html,
      isTop: isTop,
      onLink: onLink,
      onDeadLink: onDeadLink
    }) : /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: "var(--measure-prose)",
        margin: "0 auto"
      }
    }, /*#__PURE__*/React.createElement("h1", {
      className: "wh-card-title"
    }, entry.title), data.subtitle ? /*#__PURE__*/React.createElement("p", {
      className: "wh-card-title-sub"
    }, data.subtitle) : null)));
  }));
}
window.WHStackScreen = WHStackScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/StackScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/articles.js
try { (() => {
/* Canned article content for the UI kit demo.
   Link grammar inside content HTML:
   - <a data-article="Title">          internal — spawns a card
   - <a class="wh-dead" data-dead>     red link — inert, toast on click
   - <a class="wh-ext" href target>    external — new tab
   - <sup class="wh-ref"><a data-ref="id">  footnote — scrolls within card
   Images are placeholders (.wh-imgph) — the real app lazy-loads from
   Wikipedia's CDN; no imagery is bundled with the design system. */

window.WH_DATA = (() => {
  const articles = {};
  articles["Okapi"] = {
    subtitle: "Species of mammal",
    html: `
      <table class="wh-infobox">
        <caption>Okapi</caption>
        <tbody>
          <tr><td colspan="2"><div class="wh-imgph" style="aspect-ratio: 4 / 3"><span class="wh-icon" data-name="layers"></span></div>
          <div style="font-size: 11.5px; color: var(--text-faint); padding: 4px 2px 0;">Okapi at Epulu Conservation Centre</div></td></tr>
          <tr><td colspan="2" class="wh-infobox-section">Conservation status</td></tr>
          <tr><th>Status</th><td>Endangered <span style="color: var(--text-faint)">(IUCN 3.1)</span><sup class="wh-ref"><a data-ref="okapi-note-1">[1]</a></sup></td></tr>
          <tr><td colspan="2" class="wh-infobox-section">Scientific classification</td></tr>
          <tr><th>Kingdom</th><td><a data-article="Animalia">Animalia</a></td></tr>
          <tr><th>Class</th><td><a data-article="Mammalia">Mammalia</a></td></tr>
          <tr><th>Order</th><td><a data-article="Artiodactyla">Artiodactyla</a></td></tr>
          <tr><th>Family</th><td><a data-article="Giraffidae">Giraffidae</a></td></tr>
          <tr><th>Genus</th><td><i>Okapia</i></td></tr>
          <tr><th>Species</th><td><i>O. johnstoni</i></td></tr>
        </tbody>
      </table>
      <p class="wh-lead">The <b>okapi</b> (<i>Okapia johnstoni</i>) is an artiodactyl mammal that is endemic to the northeast <a data-article="Democratic Republic of the Congo">Democratic Republic of the Congo</a>. It is the only species in the genus <i>Okapia</i>. Although the okapi has striped markings reminiscent of <a data-article="Zebra">zebras</a>, it is most closely related to the <a data-article="Giraffe">giraffe</a>.<sup class="wh-ref"><a data-ref="okapi-note-2">[2]</a></sup></p>
      <p>The okapi stands about 1.5&nbsp;m tall at the shoulder. Its coat is a chocolate to reddish brown, in striking contrast with the white horizontal stripes on the legs and white ankles. Male okapis have short, hair-covered ossicones; females possess hair whorls instead.<sup class="wh-ref"><a data-ref="okapi-note-2">[2]</a></sup></p>
      <h2>Etymology</h2>
      <p>The common name comes from the <a class="wh-dead" data-dead>Lese Karo</a> name <i>o'api</i>, borrowed from the neighbouring Efé peoples of the <a data-article="Ituri Rainforest">Ituri Rainforest</a>. Early European accounts described an "African unicorn"; the species was not described scientifically until 1901.<sup class="wh-ref"><a data-ref="okapi-note-3">[3]</a></sup></p>
      <h2>Behaviour and ecology</h2>
      <p>Okapis are largely diurnal and essentially solitary, coming together only to breed. They are herbivores, feeding on tree leaves and buds, grasses, ferns, fruits, and fungi; over 100 plant species have been recorded in the diet, some of them poisonous to humans.</p>
      <figure>
        <div class="wh-imgph" style="aspect-ratio: 16 / 9"><span class="wh-icon" data-name="layers"></span></div>
        <figcaption>Forest clearing in the Ituri Rainforest, typical okapi habitat. Images load from Wikipedia's CDN and are licensed individually.</figcaption>
      </figure>
      <h2>Status</h2>
      <p>The <a class="wh-ext" href="https://www.iucnredlist.org/" target="_blank" rel="noopener">IUCN Red List</a> classifies the okapi as endangered. Major threats include habitat loss and illegal mining. Population estimates vary considerably by survey area:</p>
      <div class="wh-tablewrap"><table class="wh-table">
        <thead><tr><th>Survey area</th><th>Year</th><th style="text-align: right">Estimate</th><th>Trend</th></tr></thead>
        <tbody>
          <tr><td>Ituri landscape</td><td class="wh-num">2011</td><td class="wh-num">3,500–7,000</td><td>Declining</td></tr>
          <tr><td>Réserve de faune à okapis</td><td class="wh-num">2018</td><td class="wh-num">2,200</td><td>Declining</td></tr>
          <tr><td>Maiko National Park</td><td class="wh-num">2020</td><td class="wh-num">1,800</td><td>Unknown</td></tr>
        </tbody>
      </table></div>
      <h2>References</h2>
      <div class="wh-refs"><ol>
        <li id="okapi-note-1">Mallon, D.; Kümpel, N. (2015). "<i>Okapia johnstoni</i>". IUCN Red List of Threatened Species.</li>
        <li id="okapi-note-2">Bodmer, R.; Rabb, G. (1992). "<i>Okapia johnstoni</i>". Mammalian Species (422): 1–8.</li>
        <li id="okapi-note-3">Johnston, H. (1901). "The okapi: the newly discovered beast". Proceedings of the Zoological Society of London.</li>
      </ol></div>
    `
  };
  articles["Giraffe"] = {
    subtitle: "Tallest living terrestrial animal",
    html: `
      <p class="wh-lead">The <b>giraffe</b> is a large African hoofed mammal belonging to the genus <i>Giraffa</i>. It is the tallest living terrestrial animal and the largest ruminant on Earth.<sup class="wh-ref"><a data-ref="giraffe-note-1">[1]</a></sup></p>
      <p>The giraffe's chief distinguishing characteristics are its extremely long neck and legs, its horn-like ossicones, and its spotted coat patterns. Its closest living relative is the <a data-article="Okapi">okapi</a>, with which it forms the family <a data-article="Giraffidae">Giraffidae</a>.</p>
      <h2>Habitat</h2>
      <p>Giraffes usually inhabit savannahs and open woodlands, from Chad in the north to South Africa in the south. Large aggregations occur seasonally in the <a data-article="Serengeti">Serengeti</a> and other East African grasslands, where they browse on acacia at heights no other herbivore can reach.</p>
      <figure>
        <div class="wh-imgph" style="aspect-ratio: 3 / 2"><span class="wh-icon" data-name="layers"></span></div>
        <figcaption>Masai giraffe browsing, Serengeti National Park.</figcaption>
      </figure>
      <h2>References</h2>
      <div class="wh-refs"><ol>
        <li id="giraffe-note-1">Dagg, A. I. (2014). <i>Giraffe: Biology, Behaviour and Conservation.</i> Cambridge University Press.</li>
      </ol></div>
    `
  };
  articles["Serengeti"] = {
    subtitle: "Geographical region in Africa",
    html: `
      <p class="wh-lead">The <b>Serengeti</b> ecosystem is a geographical region in Africa, spanning northern Tanzania and southwestern Kenya. It hosts the largest terrestrial mammal migration in the world.<sup class="wh-ref"><a data-ref="serengeti-note-1">[1]</a></sup></p>
      <p>The name comes from the Maasai word <i>seringit</i>, meaning "endless plains". Over 1.5 million wildebeest and 250,000 zebra cross its plains each year, trailed by predators and, more recently, photographers. The region includes Serengeti National Park and several game reserves, and neighbours the <a class="wh-dead" data-dead>Loliondo Game Controlled Area</a>.</p>
      <p>Its volcanic soils trace to the <a data-article="Ituri Rainforest">highlands</a> to the west and support short sweet grasses that drive the migration's rhythm.</p>
      <h2>References</h2>
      <div class="wh-refs"><ol>
        <li id="serengeti-note-1">Sinclair, A. R. E. (2012). <i>Serengeti Story.</i> Oxford University Press.</li>
      </ol></div>
    `
  };
  articles["Ituri Rainforest"] = {
    subtitle: "Rainforest in the Congo Basin",
    html: `
      <p class="wh-lead">The <b>Ituri Rainforest</b> is a dense tropical forest in the northeast of the <a data-article="Democratic Republic of the Congo">Democratic Republic of the Congo</a>, named for the Ituri River which flows through it.</p>
      <p>Roughly 63,000&nbsp;km² in extent, the forest shelters the <a data-article="Okapi">okapi</a>, forest elephants, and some of the last old-growth mbau stands in Central Africa. About a fifth of it is protected as the Okapi Wildlife Reserve, a UNESCO World Heritage Site.</p>
    `
  };
  articles["Democratic Republic of the Congo"] = {
    subtitle: "Country in Central Africa",
    html: `
      <p class="wh-lead">The <b>Democratic Republic of the Congo</b> is a country in Central Africa, the second-largest on the continent. Its rainforests — including the <a data-article="Ituri Rainforest">Ituri</a> — form the heart of the Congo Basin.</p>
      <p>The country spans two time zones and holds most of the Congo River's course, the deepest river on Earth.</p>
    `
  };
  articles["Giraffidae"] = {
    subtitle: "Family of mammals",
    html: `
      <p class="wh-lead"><b>Giraffidae</b> is a family of ruminant artiodactyl mammals that today contains just two living genera — the <a data-article="Giraffe">giraffe</a> and the <a data-article="Okapi">okapi</a> — the remnant of a lineage once spread across Eurasia and Africa.</p>
      <p>Fossil giraffids such as <i>Sivatherium</i> carried moose-like antlers and stood as tall as elephants at the shoulder.</p>
    `
  };

  /* Entry-screen autocomplete pool */
  const searchPool = [{
    title: "Okapi",
    description: "Species of mammal"
  }, {
    title: "Okavango Delta",
    description: "River delta in Botswana"
  }, {
    title: "Okra",
    description: "Species of flowering plant"
  }, {
    title: "Oka River",
    description: "River in central Russia"
  }, {
    title: "Giraffe",
    description: "Tallest living terrestrial animal"
  }, {
    title: "Giraffidae",
    description: "Family of mammals"
  }, {
    title: "Serengeti",
    description: "Geographical region in Africa"
  }, {
    title: "Serendipity",
    description: "Unplanned fortunate discovery"
  }, {
    title: "Ituri Rainforest",
    description: "Rainforest in the Congo Basin"
  }, {
    title: "Democratic Republic of the Congo",
    description: "Country in Central Africa"
  }];

  /* "fall in somewhere random" pool — articles we actually have */
  const randomPool = ["Okapi", "Giraffe", "Serengeti", "Ituri Rainforest", "Giraffidae"];
  return {
    articles,
    searchPool,
    randomPool
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/articles.js", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.ArticleProse = __ds_scope.ArticleProse;

__ds_ns.ArticleCard = __ds_scope.ArticleCard;

__ds_ns.AttributionFooter = __ds_scope.AttributionFooter;

__ds_ns.CardTab = __ds_scope.CardTab;

__ds_ns.DepthBadge = __ds_scope.DepthBadge;

__ds_ns.TopBar = __ds_scope.TopBar;

__ds_ns.Wordmark = __ds_scope.Wordmark;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Overlay = __ds_scope.Overlay;

__ds_ns.TrailPanel = __ds_scope.TrailPanel;

__ds_ns.SearchField = __ds_scope.SearchField;

})();
