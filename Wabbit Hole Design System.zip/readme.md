# Wabbit Hole design system

Design system for **Wabbit Hole** (wabbithole.io), a client-side web app for wandering through Wikipedia. The user starts at any article, rendered as a card; every internal link opens the linked article as a new card stacked on the previous one. **The visible stack is the browsing history**, the record of falling down the rabbit hole. No backend, no accounts; content is fetched from Wikipedia's public APIs at runtime.

## Sources
- **Functional overview** (2026-07-03 engagement brief, pasted into this project): screens, states, behaviors, link classes, legal constraints. Deliberately contained no visual direction.
- **Live reference build**: https://wabbit-hole.vercel.app (entry-screen copy sampled from it: the tagline "Follow one link. Then another. The stack is the story of how you got here.", "or fall in somewhere random ↓", the lowercase wordmark, the licensing footer).
- No Figma, no codebase, no brand assets were provided. **The visual language here is original**, designed to read as a natural neighbor of Wikipedia (bookish, typographic, link-forward) while being unmistakably not Wikipedia, which is a Wikimedia trademark-policy requirement (see Legal).

## The idea: a stack of index cards
Every article is an index card: bright white card stock on a cool desk, a carrot-colored header rule under the active card's tab, ruling-blue lines on blank stock (image placeholders). Depth is literal: each card buries the last, tabs cascade in a tight 40px rhythm, cool gray shadows cast upward from each new sheet. Links, the product's one true mechanic, get the strongest color in the system ("portal" indigo). Carrot appears only in small moments: the header rule, footnote flashes, text selection.

---

## CONTENT FUNDAMENTALS

**Voice**: plain, warm, a little playful. The rabbit-hole metaphor is allowed in *moments* (entry screen, toasts, empty states) and banned from *labels* (chrome verbs stay literal: Back, Trail, Share, Try again).

- Sentence case everywhere; the wordmark is always lowercase ("wabbit hole"). Feature names used as labels are capitalized (Trail, Share, Export Markdown).
- Short sentences with full stops, even in taglines: "Follow one link. Then another."
- Second person, present tense, contractions welcome: "Already in your trail. Jumped back to it."
- **No em dashes.** Split into two sentences, or use a comma, colon, or semicolon.
- The ↓ / ↗ arrows may appear inline as glyphs ("or fall in somewhere random ↓").
- Numerals, never words: "4 deep", "1 card", "6 results".
- Errors are blame-free and factual, with one clear action: ""Ituri" hasn't been written yet." / "Try again".
- No emoji. No exclamation marks. Never all-caps (except rare 11px micro-labels).
- Legal copy (attribution, CC BY-SA 4.0, non-affiliation) is precise and never reworded, shortened, or made cute.
- Search placeholder is serif italic, the one place the reading voice leaks into the chrome: *start anywhere…*

## VISUAL FOUNDATIONS

- **Color**: index-card surfaces (`--wh-paper-0…3`: card #ffffff on desk #eef0f3) with cool near-black ink (`--wh-ink-1…3`). Decorative ruling blue `--wh-rule` #bccce4 (blank card stock, never text). One color per link behavior: portal indigo #4353c5 (internal), plum #8a5878 (visited), clay #a44a34 (dead/red links, also errors), portal + ↗ (external). Carrot #d9772e is the brand accent: the active card's header rule, footnote flash, ::selection, small delight; **never** for buttons or body text. Moss green exists for rare success only. No gradients.
- **The header rule**: the active card's tab carries a 2px carrot rule (the red line of an index card) and its trail number turns carrot-deep. Buried tabs carry no rule. This is the single loudest brand element on screen.
- **Type**: Literata (400/600/700 + italic) for everything readable: article body 17/1.62, measure 680px. Literata Display (36pt optical masters, 700) for the wordmark and article titles. Source Sans 3 (400/600/700) for chrome at 12 to 16px. Scale: 12 / 13 / 14 / 16 / 17 / 19 / 20 / 26 / 32 / 44 / 64. Display tracking −0.015em. Italic serif for taxa, titles of works, and the search placeholder. Text is never justified.
- **Backgrounds**: flat color only. No textures, patterns, gradients, or illustrations. The desk (paper-1) is the app backdrop; cards are paper-0. Depth is communicated by dimming (veil/scrim), never by darkening surface colors. Ruled lines appear only on blank stock (`.wh-imgph`).
- **Shadows**: cool gray (rgba(33,38,48,…)), never brown or pure black. Five levels: shadow-1 (chips) → shadow-2 (raised) → shadow-sheet (cards; soft edge cast upward) → shadow-float (panels/popovers) → shadow-toast. Cards also carry a hairline border.
- **Borders**: 1px hairlines (#e3e6eb); stronger #c9cfd8 for inputs and soft buttons. No 2px+ borders except the carrot header rule. No left-accent bars.
- **Radii**: small and crisp, like die-cut card corners: 4 (buttons/inputs/chips) · 8 (popovers/figures/toasts/search) · 10 (cards and panels; cards round the **top corners only**). When in doubt, use the small one. Pills are reserved and currently unused.
- **Spacing**: 4px base, ramp 4→80 (`--space-1…11`). Card geometry tokens: tab-height 40, tab-peek 40, card-width 840, measure-prose 680. The cascade is tight: each buried card shows exactly its tab.
- **Motion**: cards settle like card stock: `--ease-settle` cubic-bezier(0.2,0.9,0.25,1), 400ms for spawn/reopen (rise from below); 240ms swift for toasts/popovers/tints; ease-drop for dismissals falling away. The trail sidebar animates width over 240ms. No bounce, no springs, nothing infinite. `prefers-reduced-motion` ⇒ instant placement/crossfade (global override in css/components.css).
- **Hover states**: background tint shifts (transparent → paper-2, or link-tint on links/results) plus color deepening (portal → portal-deep). Never opacity fades, never underline-only.
- **Press states**: 1px translateY on buttons; darker tint (paper-3).
- **Focus**: 2px portal outline, 2px offset, on :focus-visible only.
- **Transparency & blur**: none. The only alpha surfaces are the two veils (buried-card veil, panel scrim). No backdrop-filter.
- **Layout**: top bar (56px) is transparent chrome sitting on the desk. Below it, a flex row: the collapsible Trail sidebar (300px, docked left, collapses to 0) and the stage that owns the stack. Up to 6 sheets visible, each peeking 40px above the next, subtly narrower with depth (14px per level in the kit). Under 720px, only the top card shows, full-bleed. Every card scrolls independently (`overscroll-behavior: contain`); the card never scrolls horizontally; wide tables scroll inside `.wh-tablewrap`.
- **Imagery**: the product ships none. All images arrive from Wikipedia's CDN inside article content and are individually licensed; they get radius-8, a ruled blank-stock placeholder (`.wh-imgph`), and a 12px sans caption. Never add stock or decorative imagery.
- **Cards** (the signature object): white stock, hairline border, top-only radius 10, shadow-sheet, 40px tab (number · serif title · muted subtitle) with the carrot rule when active, independently scrolling body, attribution footer. Buried cards keep a crisp interactive tab while the body is veiled and inert.

## ICONOGRAPHY

- **No proprietary icon set exists.** The system uses a copied subset of **Lucide** (ISC license) in `assets/icons/`: 24px grid, 2px stroke, round caps, chosen to sit quietly next to Source Sans 3. This is a flagged substitution; swap the SVGs if the brand acquires its own set.
- Icons are always **masked to currentColor** via `.wh-icon[data-name="…"]` (see css/components.css) or the `Icon` React component. Never inline `<img>`, never recolored SVG files.
- Usage is chrome-only: icons never appear inside article prose. Sizes 13 to 22px, always paired with a text label except in `IconButton` (which requires an aria-label).
- Set (14): search, shuffle, arrow-left, arrow-down, x, link, external-link, download, list, layers, rotate-ccw, corner-right-down, info, chevron-right.
- Unicode glyphs are part of the voice: ↗ marks external links (CSS ::after), ↓ appears in entry-screen copy, · separates metadata, ↵ marks the Enter hint.
- No emoji, ever.

## Logo

No final logo mark has been adopted. The identity today is the type-only lowercase wordmark "wabbit hole" in Literata Display Bold (`components/chrome/Wordmark.jsx`). **Five candidate rabbit/W marks are in `explorations/logo-marks.html`** (options 1a to 1e); once one is chosen it gets cut into `assets/` and wired into the Wordmark component, top bar, and entry screen.

## Legal constraints (bake into everything)

1. Every card ends with `AttributionFooter`: source article link + CC BY-SA 4.0 link + "reformatted, some elements omitted". Site-level copy mentions GFDL and per-image licensing (see About panel in the UI kit).
2. Must be recognizably **not Wikipedia**: no puzzle globe, no "W" plaque marks, no Linux Libertine/serif-wordmark lookalikes, no Wikipedia blue (#3366cc) / red (#d33) / visited-purple values.
3. Always state non-affiliation with the Wikimedia Foundation.
4. Accessibility: buried cards inert; stack changes announced via live region; reduced-motion honored; buried tabs remain distinguishable click targets.

---

## Index

```
styles.css                 ← the only file consumers must link
tokens/                    colors · typography · spacing · elevation · motion · fonts (@font-face)
css/article.css            .wh-prose: encyclopedia content (links, infobox, tables, refs, figures)
css/components.css         all wh-* component classes + keyframes + reduced-motion
assets/fonts/              Literata + Literata 36pt (TTF), Source Sans 3 (WOFF2), OFL licenses
assets/icons/              14 Lucide SVGs (masked via .wh-icon)
components/                React sugar over the CSS classes (one dir per concern)
guidelines/                foundation specimen cards (Design System tab)
ui_kits/app/               clickable recreation of the whole product
explorations/              logo mark candidates (1a to 1e), awaiting a pick
templates/                 starting points for consuming projects
```

**Components** (`window.WabbitHoleDesignSystem_ca83f3`), each with `.jsx`, `.d.ts`, `.prompt.md`, and a card:
- `components/icons/`: **Icon**
- `components/actions/`: **Button**, **IconButton**
- `components/search/`: **SearchField**
- `components/feedback/`: **Toast**
- `components/chrome/`: **TopBar**, **Wordmark**, **DepthBadge**
- `components/card/`: **ArticleCard**, **CardTab**, **AttributionFooter**
- `components/panels/`: **Overlay** (modal, e.g. About), **TrailPanel** (docked collapsible left sidebar)
- `components/article/`: **ArticleProse**

**UI kit**: `ui_kits/app/index.html`: entry → stack → trail sidebar → about, fully interactive (see its README).

**Templates** (starting points for consuming projects): `templates/card-stack/` (top bar + three-deep stack) and `templates/entry-screen/` (the empty state).

**Intentional additions** (no source inventory existed; the component set was derived from the functional overview): `Icon` (wrapper for the copied Lucide set) and `Overlay` (shared modal shell for the About panel described in the brief).

## Notes & caveats
- **Fonts are Google-Fonts/Adobe originals, not brand-supplied**: Literata (googlefonts/literata @ main) and Source Sans 3 (adobe-fonts/source-sans @ release), both OFL; licenses in assets/fonts/. If the brand has real font files, replace the binaries and keep the @font-face names.
- The stack geometry (40px cascade, 14px width step, 5 visible) lives in the UI kit, not the components; the brief marks it "replaceable".
- Article styling targets both `.wh-*` classes and raw Wikipedia classes (.infobox, .wikitable, .reflist, sup.reference), since real content arrives with Wikipedia markup.
- Math notation: styled as inline images (`.mwe-math-element img`); no specimen exists yet and it needs a real technical article to validate.
