---
name: wabbit-hole-design
description: Use this skill to generate well-branded interfaces and assets for Wabbit Hole (wabbithole.io), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Quick orientation:
- Link `styles.css` (root) for all tokens, fonts, article styling (`.wh-prose`) and component classes (`wh-*`); the CSS works without React.
- React components live in `components/` and compile to `window.WabbitHoleDesignSystem_ca83f3`.
- The full clickable product recreation is `ui_kits/app/index.html`. Logo mark candidates live in `explorations/logo-marks.html`.
- Hard rules: index-card palette (white stock on a cool desk, never Wikipedia's colors), Literata + Source Sans 3, lowercase type wordmark (logo marks are in exploration; do not invent new ones ad hoc), the active card's tab carries the 2px carrot header rule, every article card ends with the CC BY-SA 4.0 attribution footer, small crisp radii (default 4px), no emoji, no em dashes, honor prefers-reduced-motion.
