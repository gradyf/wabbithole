Inline UI glyph from the copied Lucide set — use for chrome affordances, never inside article prose.

```jsx
<Icon name="shuffle" size={16} />
```

Names: search, shuffle, arrow-left, arrow-down, x, link, external-link, download, list, layers, rotate-ccw, corner-right-down, info, chevron-right. Takes currentColor from its parent.
