import React from "react";

/** Glyph from the copied Lucide set (assets/icons), masked to currentColor. */
export function Icon({ name, size = 16, style, ...rest }) {
  return (
    <span
      className="wh-icon"
      data-name={name}
      style={{ width: size, height: size, ...style }}
      aria-hidden="true"
      {...rest}
    ></span>
  );
}
