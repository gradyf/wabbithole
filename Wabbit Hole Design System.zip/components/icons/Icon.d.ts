import * as React from "react";

export type IconName =
  | "search"
  | "shuffle"
  | "arrow-left"
  | "arrow-down"
  | "x"
  | "link"
  | "external-link"
  | "download"
  | "list"
  | "layers"
  | "rotate-ccw"
  | "corner-right-down"
  | "info"
  | "chevron-right";

/** Inline glyph from the project's copied Lucide icon set. Renders as a
 *  CSS-masked span so it inherits currentColor. Decorative by default
 *  (aria-hidden); pair with a text label or aria-label on the parent. */
export interface IconProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Icon file name in assets/icons (without .svg). */
  name: IconName;
  /** Square size in px. Default 16. */
  size?: number;
}

export declare function Icon(props: IconProps): React.ReactElement;
