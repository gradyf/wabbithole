Article search with live autocomplete — the "start anywhere" field on the entry screen and anywhere an article needs picking.

```jsx
<SearchField
  size="lg"
  results={[{ title: "Okapi", description: "Species of mammal" }]}
  onSelect={(r) => openArticle(r.title)}
/>
```

Keyboard loop is built in (arrows / Enter / Escape). `size="lg"` for the entry hero; default md for compact contexts. Results cap at 6.
