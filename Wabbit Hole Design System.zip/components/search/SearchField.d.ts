import * as React from "react";

export interface SearchResult {
  /** Article title, e.g. "Okapi". */
  title: string;
  /** Wikipedia's one-line description, e.g. "Species of mammal". Optional. */
  description?: string;
}

/** Article search with live autocomplete (up to 6 rows). Built-in keyboard
 *  loop: arrows move, Enter opens (top result when nothing highlighted),
 *  Escape closes. Serif italic placeholder is part of the voice. */
export interface SearchFieldProps {
  /** Default "start anywhere…". */
  placeholder?: string;
  /** "lg" for the entry screen hero, "md" (default) elsewhere. */
  size?: "md" | "lg";
  /** Controlled value; omit to let the field manage its own state. */
  value?: string;
  onChange?: (value: string) => void;
  /** Autocomplete rows for the current value (max 6 shown). */
  results?: SearchResult[];
  /** Called with the chosen result on click or Enter. */
  onSelect?: (result: SearchResult) => void;
  /** Called when Escape closes the dropdown. */
  onDismiss?: () => void;
  autoFocus?: boolean;
}

export declare function SearchField(props: SearchFieldProps): React.ReactElement;
