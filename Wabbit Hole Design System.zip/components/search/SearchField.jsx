import React from "react";

/** Article search with live autocomplete. Handles its own keyboard loop
 *  (arrows / Enter / Escape) and value state unless controlled. */
export function SearchField({
  placeholder = "start anywhere…",
  size = "md",
  value,
  onChange,
  results = [],
  onSelect,
  onDismiss,
  autoFocus,
  ...rest
}) {
  const [innerValue, setInnerValue] = React.useState("");
  const [active, setActive] = React.useState(-1);
  const [closed, setClosed] = React.useState(false);
  const val = value !== undefined ? value : innerValue;
  const open = !closed && val.trim().length > 0 && results.length > 0;

  const setVal = (v) => {
    if (value === undefined) setInnerValue(v);
    if (onChange) onChange(v);
    setClosed(false);
    setActive(-1);
  };

  const pick = (i) => {
    const r = results[i] || results[0];
    if (r && onSelect) onSelect(r);
  };

  const onKeyDown = (e) => {
    if (e.key === "ArrowDown" && open) {
      e.preventDefault();
      setActive((a) => (a + 1) % results.length);
    } else if (e.key === "ArrowUp" && open) {
      e.preventDefault();
      setActive((a) => (a <= 0 ? results.length - 1 : a - 1));
    } else if (e.key === "Enter" && open) {
      e.preventDefault();
      pick(active === -1 ? 0 : active);
    } else if (e.key === "Escape") {
      setClosed(true);
      setActive(-1);
      if (onDismiss) onDismiss();
    }
  };

  return (
    <div className="wh-search" data-size={size} {...rest}>
      <div className="wh-search-box">
        <span className="wh-icon" data-name="search" aria-hidden="true"></span>
        <input
          type="text"
          role="combobox"
          aria-expanded={open}
          aria-autocomplete="list"
          placeholder={placeholder}
          value={val}
          autoFocus={autoFocus}
          onChange={(e) => setVal(e.target.value)}
          onKeyDown={onKeyDown}
        />
      </div>
      {open ? (
        <div className="wh-search-pop" role="listbox">
          {results.slice(0, 6).map((r, i) => (
            <div
              key={r.title}
              className="wh-result"
              role="option"
              aria-selected={i === active}
              data-active={i === active ? "" : undefined}
              onMouseEnter={() => setActive(i)}
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => pick(i)}
            >
              <span className="wh-result-title">{r.title}</span>
              <span className="wh-result-desc">{r.description}</span>
              {i === active ? <span className="wh-kbd">↵</span> : null}
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
}
