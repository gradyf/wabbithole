import * as React from "react";

/** The type-only wordmark, always lowercase "wabbit hole" in Literata Display
 *  Bold. No drawn logo mark exists. In the top bar it acts as "start over". */
export interface WordmarkProps extends React.HTMLAttributes<HTMLElement> {
  /** "bar" (20px, default) or "hero" (entry screen, clamps to 64px). */
  size?: "bar" | "hero";
  /** When provided the wordmark renders as a button (start over). */
  onClick?: React.MouseEventHandler;
}

export declare function Wordmark(props: WordmarkProps): React.ReactElement;
