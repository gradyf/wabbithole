import * as React from "react";

/** Persistent top bar while cards are open: wordmark (start over), Back
 *  (hidden at depth 1), depth chip, Trail, Share. Sits directly on the desk —
 *  no border or fill of its own. */
export interface TopBarProps extends React.HTMLAttributes<HTMLElement> {
  /** Cards in the trail; Back renders only when > 1. */
  depth?: number;
  /** Return to the previous card. */
  onBack?: () => void;
  /** Open the trail panel. */
  onTrail?: () => void;
  /** Copy the trail URL (confirm with a toast). */
  onShare?: () => void;
  /** Wordmark click — return to the entry screen. */
  onHome?: () => void;
  /** Hide the depth chip (narrow viewports). */
  hideDepth?: boolean;
}

export declare function TopBar(props: TopBarProps): React.ReactElement;
