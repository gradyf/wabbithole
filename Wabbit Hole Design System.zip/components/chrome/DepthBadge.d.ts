import * as React from "react";

/** Depth indicator chip — reads "1 card", then "N deep". Lives in the top
 *  bar; hidden on narrow viewports. */
export interface DepthBadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Number of cards in the trail. */
  count: number;
}

export declare function DepthBadge(props: DepthBadgeProps): React.ReactElement;
