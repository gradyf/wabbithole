Persistent app bar while cards are open — wordmark (start over) left; Back, depth chip, Trail, Share right. Transparent: it sits directly on the desk.

```jsx
<TopBar depth={4} onBack={pop} onTrail={openTrail} onShare={copyLink} onHome={reset} />
```

Back auto-hides at depth 1. `hideDepth` for narrow viewports.
