import React from "react";

/** Type-only wordmark — no logo mark exists (see readme). Lowercase always. */
export function Wordmark({ size = "bar", onClick, style, ...rest }) {
  const El = onClick ? "button" : "span";
  return (
    <El
      className="wh-wordmark"
      data-size={size === "hero" ? "hero" : undefined}
      onClick={onClick}
      title={onClick ? "Start over" : undefined}
      style={style}
      {...rest}
    >
      wabbit hole
    </El>
  );
}
