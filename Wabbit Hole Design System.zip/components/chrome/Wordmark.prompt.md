The type-only wordmark ("wabbit hole", lowercase, Literata Display Bold). There is no drawn logo mark — never invent one.

```jsx
<Wordmark size="hero" />
<Wordmark onClick={startOver} />  {/* top bar — acts as "start over" */}
```

Sizes: bar (default) / hero.
