import React from "react";

/** "1 card" / "N deep" chip. Hide on narrow viewports. */
export function DepthBadge({ count = 1, ...rest }) {
  return (
    <span className="wh-depth" {...rest}>
      <span className="wh-icon" data-name="layers" aria-hidden="true"></span>
      {count === 1 ? "1 card" : `${count} deep`}
    </span>
  );
}
