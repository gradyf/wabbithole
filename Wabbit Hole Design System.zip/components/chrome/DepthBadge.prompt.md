Depth indicator chip for the top bar — "1 card", then "4 deep".

```jsx
<DepthBadge count={trail.length} />
```

Hide it on narrow viewports; the trail panel carries the count there.
