import React from "react";
import { Wordmark } from "./Wordmark.jsx";
import { DepthBadge } from "./DepthBadge.jsx";

/** Persistent app bar while cards are open. Back hides at depth 1;
 *  the wordmark is "start over". */
export function TopBar({ depth = 1, onBack, onTrail, onShare, onHome, hideDepth, ...rest }) {
  return (
    <header className="wh-topbar" {...rest}>
      <Wordmark onClick={onHome} />
      <div className="wh-topbar-spacer"></div>
      {depth > 1 ? (
        <button type="button" className="wh-btn" data-variant="ghost" onClick={onBack}>
          <span className="wh-icon" data-name="arrow-left" aria-hidden="true"></span>
          Back
        </button>
      ) : null}
      {hideDepth ? null : <DepthBadge count={depth} />}
      <button type="button" className="wh-btn" data-variant="ghost" onClick={onTrail}>
        <span className="wh-icon" data-name="list" aria-hidden="true"></span>
        Trail
      </button>
      <button type="button" className="wh-btn" data-variant="soft" onClick={onShare}>
        <span className="wh-icon" data-name="link" aria-hidden="true"></span>
        Share
      </button>
    </header>
  );
}
