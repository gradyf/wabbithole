import * as React from "react";

/** Applies the .wh-prose reading scope to encyclopedia content: serif body,
 *  link behaviors (internal / dead / external / footnote), headings, figures,
 *  infoboxes, tables (horizontal scroll via .wh-tablewrap), reference lists,
 *  and the footnote flash. Handles Wikipedia's own markup classes too
 *  (.infobox, .wikitable, .reflist, sup.reference). */
export interface ArticleProseProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Fetched article HTML (already sanitized upstream). */
  html?: string;
  /** Or compose curated content as children. */
  children?: React.ReactNode;
}

export declare function ArticleProse(props: ArticleProseProps): React.ReactElement;
