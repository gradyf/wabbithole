import React from "react";

/** Wrapper that styles encyclopedia HTML (.wh-prose scope). Pass fetched
 *  markup via `html`, or compose children for curated content. */
export function ArticleProse({ html, children, ...rest }) {
  if (html !== undefined) {
    return <div className="wh-prose" dangerouslySetInnerHTML={{ __html: html }} {...rest}></div>;
  }
  return (
    <div className="wh-prose" {...rest}>
      {children}
    </div>
  );
}
