Reading scope for encyclopedia content — serif body, all four link classes, headings, figures, infoboxes, scrolling tables, reference lists.

```jsx
<ArticleProse html={fetchedArticleHtml} />
```

Or compose curated content as children. Link classes: default `<a>` = internal (spawns a card), `.wh-dead` = inert red-link, `.wh-ext` = external (↗, new tab), `sup.wh-ref > a` = footnote. Wrap wide tables in `.wh-tablewrap`.
