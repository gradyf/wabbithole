Card header strip — trail number, serif title, muted subtitle. The only part of a buried card that stays interactive.

```jsx
<CardTab index={2} title="Giraffe" subtitle="Tallest living terrestrial animal" buried onClick={reopen} />
```

Omit `buried` on the top card (inert header). Usually composed via ArticleCard.
