import React from "react";

/** Required licensing line at the end of every card's scroll content. */
export function AttributionFooter({ title, href, ...rest }) {
  const src = href || `https://en.wikipedia.org/wiki/${encodeURIComponent(String(title || "").replace(/ /g, "_"))}`;
  return (
    <footer className="wh-attrib" {...rest}>
      Content from the Wikipedia article{" "}
      <a href={src} target="_blank" rel="noopener">
        {title}
      </a>
      , reformatted for this reader with some elements omitted. Text is available under{" "}
      <a href="https://creativecommons.org/licenses/by-sa/4.0/" target="_blank" rel="noopener">
        CC BY-SA 4.0
      </a>
      ; images are licensed individually.
    </footer>
  );
}
