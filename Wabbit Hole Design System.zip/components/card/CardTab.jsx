import React from "react";

/** Card header strip — always visible, even buried. Buried tabs are a single
 *  click target that reopens the card; the top card's tab is inert. */
export function CardTab({ index, title, subtitle, buried, onClick, ...rest }) {
  const content = (
    <React.Fragment>
      <span className="wh-tab-num">{index}</span>
      <span className="wh-tab-title">{title}</span>
      {subtitle ? <span className="wh-tab-sub">{subtitle}</span> : null}
    </React.Fragment>
  );
  if (buried) {
    return (
      <button
        type="button"
        className="wh-tab"
        data-buried=""
        onClick={onClick}
        aria-label={`Return to ${title} — card ${index}`}
        {...rest}
      >
        {content}
      </button>
    );
  }
  return (
    <div className="wh-tab" {...rest}>
      {content}
    </div>
  );
}
