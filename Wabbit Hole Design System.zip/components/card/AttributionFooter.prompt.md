Required licensing line ending every card — links the source article and CC BY-SA 4.0, states content was modified. Never omit it; never reword the license.

```jsx
<AttributionFooter title="Okapi" />
```

`href` overrides the default en.wikipedia.org URL (other language editions).
