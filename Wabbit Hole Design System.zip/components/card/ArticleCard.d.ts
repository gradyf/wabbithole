import * as React from "react";

/** An article rendered as a card — the product's core object. Composes the
 *  tab strip, an independently scrolling body (scroll never chains), and the
 *  required attribution footer. `state` covers the full lifecycle; buried
 *  bodies are veiled and inert while the tab stays interactive. */
export interface ArticleCardProps extends React.HTMLAttributes<HTMLElement> {
  /** 1-based position in the trail. */
  index: number;
  /** Article title (also drives the default attribution link). */
  title: string;
  /** Wikipedia's one-line description; omit when unavailable. */
  subtitle?: string;
  /** top of stack: "active". Behind: "buried". Fetching: "loading".
   *  Failed: "error". Memory-dropped deep cards: "resting". */
  state?: "active" | "buried" | "loading" | "error" | "resting";
  /** Reopen handler — buried cards only (the whole tab is the target). */
  onTabClick?: () => void;
  /** "Try again" handler for the error state. */
  onRetry?: () => void;
  /** Error copy; distinct messages for missing article / rate limit / network. */
  errorMessage?: string;
  /** Play the spawn animation (reduced-motion falls back to instant). */
  entering?: boolean;
  /** Source URL override for the attribution footer. */
  sourceHref?: string;
  /** Article content — typically an ArticleProse subtree. */
  children?: React.ReactNode;
}

export declare function ArticleCard(props: ArticleCardProps): React.ReactElement;
