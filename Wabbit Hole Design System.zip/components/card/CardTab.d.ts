import * as React from "react";

/** The card's header strip: position number, article title, one-line
 *  subtitle. Always visible, even when the card is buried. Buried tabs render
 *  as a full-width button that reopens the card; the top card's tab is inert. */
export interface CardTabProps {
  /** 1-based position in the trail. */
  index: number;
  /** Article title. */
  title: string;
  /** Wikipedia's short description ("Species of mammal") — not always available. */
  subtitle?: string;
  /** Buried tabs are clickable reopen targets. */
  buried?: boolean;
  /** Reopen handler (buried only). */
  onClick?: () => void;
}

export declare function CardTab(props: CardTabProps): React.ReactElement;
