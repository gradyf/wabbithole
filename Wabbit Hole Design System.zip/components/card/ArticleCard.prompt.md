An article as a card — tab strip, independently scrolling body, attribution footer. The core object of the product.

```jsx
<ArticleCard index={3} title="Serengeti" subtitle="Ecosystem in Africa" state="active" entering>
  <ArticleProse>…article content…</ArticleProse>
</ArticleCard>
```

States: active / buried (veiled + inert body, clickable tab) / loading (skeleton) / error (`errorMessage` + `onRetry`) / resting (hibernated). The parent owns stack geometry — width, offsets, z-order.
