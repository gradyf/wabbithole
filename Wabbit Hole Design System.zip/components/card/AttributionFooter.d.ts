import * as React from "react";

/** Legally required attribution at the end of every card's scroll content:
 *  links to the source article and CC BY-SA 4.0, and states the content was
 *  modified. Do not remove or reword the license references. */
export interface AttributionFooterProps {
  /** Source article title. */
  title: string;
  /** Source article URL; defaults to en.wikipedia.org/wiki/<title>. */
  href?: string;
}

export declare function AttributionFooter(props: AttributionFooterProps): React.ReactElement;
