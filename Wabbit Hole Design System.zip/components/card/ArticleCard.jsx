import React from "react";
import { CardTab } from "./CardTab.jsx";
import { AttributionFooter } from "./AttributionFooter.jsx";

function LoadingBody() {
  const bar = (w, h = 14, mb = 12) => (
    <div className="wh-skel" style={{ width: w, height: h, marginBottom: mb }}></div>
  );
  return (
    <div style={{ maxWidth: "var(--measure-prose)", margin: "0 auto" }} aria-hidden="true">
      {bar("46%", 30, 22)}
      {bar("30%", 12, 28)}
      {bar("100%")}
      {bar("97%")}
      {bar("99%")}
      {bar("62%", 14, 28)}
      {bar("100%")}
      {bar("94%")}
      {bar("42%")}
    </div>
  );
}

/** An article as a card: tab strip, independently scrolling body, required
 *  attribution footer. `state` renders the full lifecycle. */
export function ArticleCard({
  index,
  title,
  subtitle,
  state = "active",
  onTabClick,
  onRetry,
  errorMessage,
  entering,
  sourceHref,
  children,
  className,
  ...rest
}) {
  const buried = state === "buried";
  let body;
  if (state === "loading") {
    body = <LoadingBody />;
  } else if (state === "error") {
    body = (
      <div className="wh-note">
        <span className="wh-icon" data-name="rotate-ccw" aria-hidden="true"></span>
        <p className="wh-note-title">That didn't load</p>
        <p className="wh-note-body">{errorMessage || "Something went wrong on the way down. Wikipedia may be busy."}</p>
        <button type="button" className="wh-btn" data-size="sm" onClick={onRetry}>
          Try again
        </button>
      </div>
    );
  } else if (state === "resting") {
    body = (
      <div className="wh-note">
        <span className="wh-icon" data-name="layers" aria-hidden="true"></span>
        <p className="wh-note-title">Resting</p>
        <p className="wh-note-body">This card set down its content to save memory. Reopen it and everything comes right back.</p>
      </div>
    );
  } else {
    body = (
      <React.Fragment>
        {children}
        {title ? <AttributionFooter title={title} href={sourceHref} /> : null}
      </React.Fragment>
    );
  }

  return (
    <section
      className={["wh-card", entering ? "wh-card-enter" : "", className || ""].join(" ").trim()}
      data-state={state}
      aria-label={`${title} — card ${index}`}
      {...rest}
    >
      <CardTab index={index} title={title} subtitle={subtitle} buried={buried} onClick={onTabClick} />
      <div className="wh-card-body" {...(buried ? { inert: "" } : {})}>
        {body}
      </div>
    </section>
  );
}
