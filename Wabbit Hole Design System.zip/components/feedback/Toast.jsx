import React from "react";

/** Self-dismissing status pill, bottom-center. Render conditionally;
 *  ~3.5s lifetime is the caller's job. */
export function Toast({ children, inline, style, ...rest }) {
  return (
    <div
      className="wh-toast"
      role="status"
      style={inline ? { position: "static", transform: "none", animation: "none", width: "max-content", ...style } : style}
      {...rest}
    >
      {children}
    </div>
  );
}
