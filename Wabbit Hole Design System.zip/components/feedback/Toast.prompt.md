Self-dismissing ink pill for status messages — link copied, already-in-trail, rate limits.

```jsx
{toast ? <Toast>Already in your trail. Jumped back to it.</Toast> : null}
```

Fixed bottom-center; show one at a time for ~3.5s. `inline` renders it in normal flow for documentation.
