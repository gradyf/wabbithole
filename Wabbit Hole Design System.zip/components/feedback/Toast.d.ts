import * as React from "react";

/** Ink-on-paper status pill, fixed bottom-center, self-dismissing (~3.5s —
 *  timing is the caller's job). One at a time; never stack toasts. */
export interface ToastProps extends React.HTMLAttributes<HTMLDivElement> {
  /** The message, e.g. "Already in your trail. Jumped back to it." */
  children: React.ReactNode;
  /** Render in normal flow (for specimens/docs) instead of fixed position. */
  inline?: boolean;
}

export declare function Toast(props: ToastProps): React.ReactElement;
