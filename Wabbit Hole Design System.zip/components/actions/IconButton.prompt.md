Square icon-only control for compact chrome — closing panels, clearing a field.

```jsx
<IconButton icon="x" label="Close trail" onClick={close} />
```

`label` is required (aria-label + tooltip). Sizes: md (default) / sm.
