import * as React from "react";
import type { IconName } from "../icons/Icon";

/** Square icon-only control for compact chrome (close panel, clear search). */
export interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Glyph from the Lucide set. */
  icon: IconName;
  /** Required accessible name (becomes aria-label + title). */
  label: string;
  /** "md" (default, 36px) or "sm" (30px). */
  size?: "sm" | "md";
}

export declare function IconButton(props: IconButtonProps): React.ReactElement;
