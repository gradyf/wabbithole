Chrome button for app actions — solid for the single primary action, soft for raised chips, ghost for quiet top-bar controls.

```jsx
<Button variant="soft" size="sm" icon="download" onClick={exportTrail}>
  Export Markdown
</Button>
```

Variants: solid (default) / soft / ghost. Sizes: md (default) / sm. `icon` takes a Lucide name. Never use buttons for article links — internal links spawn cards.
