import React from "react";

/** Chrome button. Solid = the rare primary action; soft = raised paper chip;
 *  ghost = quiet top-bar control. */
export function Button({ variant = "solid", size = "md", icon, children, ...rest }) {
  return (
    <button type="button" className="wh-btn" data-variant={variant} data-size={size} {...rest}>
      {icon ? <span className="wh-icon" data-name={icon} aria-hidden="true"></span> : null}
      {children}
    </button>
  );
}
