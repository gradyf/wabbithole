import React from "react";

/** Square icon-only control. Always give it a label for assistive tech. */
export function IconButton({ icon, label, size = "md", ...rest }) {
  return (
    <button type="button" className="wh-iconbtn" data-size={size} aria-label={label} title={label} {...rest}>
      <span className="wh-icon" data-name={icon} aria-hidden="true"></span>
    </button>
  );
}
