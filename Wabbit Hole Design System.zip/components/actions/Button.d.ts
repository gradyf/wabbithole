import * as React from "react";
import type { IconName } from "../icons/Icon";

/** Chrome button for app actions (Share, Try again, Export Markdown).
 *  Article links are never buttons — links spawn cards. */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** "solid" (default) for the one primary action in view; "soft" for raised
   *  paper chips; "ghost" for quiet top-bar controls. */
  variant?: "solid" | "soft" | "ghost";
  /** "md" (default, 36px) or "sm" (30px). */
  size?: "sm" | "md";
  /** Optional leading glyph from the Lucide set. */
  icon?: IconName;
  children?: React.ReactNode;
}

export declare function Button(props: ButtonProps): React.ReactElement;
