Scrim + floating paper panel — the shell for Trail, About, and future overlays.

```jsx
<Overlay open={show} onClose={hide} title="About" side="center">
  <p>…</p>
</Overlay>
```

Sides: right (full-height, lists) / center (dialog, prose). Escape and scrim-click close. `footer` pins an action row.
