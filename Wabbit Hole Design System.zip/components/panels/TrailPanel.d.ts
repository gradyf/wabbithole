import * as React from "react";

export interface TrailEntry {
  title: string;
  subtitle?: string;
}

/** The whole trail as a docked, collapsible LEFT sidebar: number, title,
 *  subtitle per card; selecting an entry reopens that card. Footer: Export
 *  Markdown + card count. Not an overlay: mount it as the first child of a
 *  flex row, with the stack stage beside it. */
export interface TrailPanelProps {
  /** Expanded (true, default) or collapsed to zero width. */
  open?: boolean;
  /** Cards in trail order (oldest first). */
  entries: TrailEntry[];
  /** Index of the card currently on top (highlighted). */
  currentIndex?: number;
  /** Reopen the card at index i. */
  onSelect?: (i: number) => void;
  /** Download the trail as a numbered Markdown list. */
  onExport?: () => void;
  /** Collapse handler (header control). Omit to hide the control. */
  onClose?: () => void;
}

export declare function TrailPanel(props: TrailPanelProps): React.ReactElement;
