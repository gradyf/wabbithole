import React from "react";

/** The trail as a docked, collapsible left sidebar: every card in order;
 *  selecting one reopens it. Collapse with the header control or the top
 *  bar's Trail button. */
export function TrailPanel({ open = true, entries = [], currentIndex, onSelect, onExport, onClose }) {
  const count = entries.length;
  return (
    <aside className="wh-sidebar" data-collapsed={open ? undefined : ""} aria-label="Trail" aria-hidden={!open}>
      <div className="wh-sidebar-inner">
        <div className="wh-sidebar-head">
          <h2 className="wh-panel-title">Trail</h2>
          {onClose ? (
            <button type="button" className="wh-iconbtn" data-size="sm" aria-label="Collapse trail" title="Collapse trail" onClick={onClose}>
              <span className="wh-icon" data-name="arrow-left" aria-hidden="true"></span>
            </button>
          ) : null}
        </div>
        <div className="wh-sidebar-body" role="list">
          {entries.map((entry, i) => (
            <button
              type="button"
              role="listitem"
              key={`${entry.title}-${i}`}
              className="wh-trail-item"
              data-current={i === currentIndex ? "" : undefined}
              onClick={() => onSelect && onSelect(i)}
            >
              <span className="wh-trail-num">{i + 1}</span>
              <span className="wh-trail-text">
                <span className="wh-trail-title">{entry.title}</span>
                {entry.subtitle ? <span className="wh-trail-sub">{entry.subtitle}</span> : null}
              </span>
              {i === currentIndex ? null : (
                <span className="wh-icon" data-name="chevron-right" aria-hidden="true" style={{ alignSelf: "center", color: "var(--text-faint)", width: 14, height: 14 }}></span>
              )}
            </button>
          ))}
        </div>
        <div className="wh-sidebar-foot">
          <button type="button" className="wh-btn" data-variant="soft" data-size="sm" onClick={onExport}>
            <span className="wh-icon" data-name="download" aria-hidden="true"></span>
            Export Markdown
          </button>
          <div className="wh-topbar-spacer"></div>
          <span style={{ fontSize: "var(--text-label)", color: "var(--text-faint)", fontVariantNumeric: "tabular-nums" }}>
            {count === 1 ? "1 card" : `${count} cards`}
          </span>
        </div>
      </div>
    </aside>
  );
}
