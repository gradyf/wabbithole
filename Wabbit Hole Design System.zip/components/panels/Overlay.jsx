import React from "react";

/** Scrim + floating panel for Trail and About. Escape and scrim-click close. */
export function Overlay({ open = true, onClose, title, side = "right", children, footer, ...rest }) {
  React.useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => {
      if (e.key === "Escape" && onClose) onClose();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div
      className="wh-overlay"
      onClick={(e) => {
        if (e.target === e.currentTarget && onClose) onClose();
      }}
    >
      <div className="wh-panel" data-side={side} role="dialog" aria-modal="true" aria-label={title} {...rest}>
        <div className="wh-panel-head">
          <h2 className="wh-panel-title">{title}</h2>
          <button type="button" className="wh-iconbtn" data-size="sm" aria-label="Close" onClick={onClose}>
            <span className="wh-icon" data-name="x" aria-hidden="true"></span>
          </button>
        </div>
        <div className="wh-panel-body" data-pad={side === "center" ? "" : undefined}>
          {children}
        </div>
        {footer ? <div className="wh-panel-foot">{footer}</div> : null}
      </div>
    </div>
  );
}
