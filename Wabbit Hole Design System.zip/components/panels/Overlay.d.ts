import * as React from "react";

/** Scrim + floating paper panel — the shell behind Trail and About.
 *  Escape and scrim-click both close. One overlay at a time. */
export interface OverlayProps {
  open?: boolean;
  onClose?: () => void;
  /** Panel heading, serif. */
  title: string;
  /** "right" (default): full-height floating panel. "center": dialog card
   *  with padded prose body (About). */
  side?: "right" | "center";
  children?: React.ReactNode;
  /** Optional pinned footer row (actions). */
  footer?: React.ReactNode;
}

export declare function Overlay(props: OverlayProps): React.ReactElement | null;
