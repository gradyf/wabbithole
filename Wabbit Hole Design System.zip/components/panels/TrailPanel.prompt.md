The trail as a docked, collapsible left sidebar: every card in order; picking one reopens it. Footer holds Export Markdown and the card count.

```jsx
<div style={{ display: "flex", flex: 1, minHeight: 0 }}>
  <TrailPanel
    open={trailOpen}
    entries={[{ title: "Okapi", subtitle: "Species of mammal" }, { title: "Giraffe" }]}
    currentIndex={1}
    onSelect={reopen}
    onExport={downloadMarkdown}
    onClose={() => setTrailOpen(false)}
  />
  {/* stack stage here */}
</div>
```

`open` animates between 300px and collapsed. The top bar's Trail button toggles it. Use `Overlay` for modal surfaces (About); this one is furniture, not a dialog.
