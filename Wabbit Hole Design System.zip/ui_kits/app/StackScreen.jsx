/* Stack screen — the cascading card stack on the desk. */
const { ArticleCard, ArticleProse } = window.WabbitHoleDesignSystem_ca83f3;

const VISIBLE_CARDS = 5; /* older cards live in the Trail panel */

function WHArticleContent({ title, subtitle, html, isTop, onLink, onDeadLink }) {
  const titleRef = React.useRef(null);

  React.useEffect(() => {
    if (isTop && titleRef.current) titleRef.current.focus({ preventScroll: true });
  }, [isTop]);

  const handleClick = (e) => {
    const a = e.target.closest ? e.target.closest("a") : null;
    if (!a) return;
    if (a.dataset.article !== undefined) {
      e.preventDefault();
      onLink(a.dataset.article);
    } else if (a.dataset.dead !== undefined) {
      e.preventDefault();
      onDeadLink(a.textContent);
    } else if (a.dataset.ref !== undefined) {
      e.preventDefault();
      const body = a.closest(".wh-card-body");
      const li = body && body.querySelector("#" + a.dataset.ref);
      if (!body || !li) return;
      const top = li.getBoundingClientRect().top - body.getBoundingClientRect().top + body.scrollTop - 56;
      const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      body.scrollTo({ top, behavior: reduced ? "auto" : "smooth" });
      li.classList.remove("wh-flash");
      void li.offsetWidth;
      li.classList.add("wh-flash");
    }
  };

  return (
    <div onClick={handleClick}>
      <h1 className="wh-card-title" tabIndex={-1} ref={titleRef} style={{ outline: "none" }}>
        {title}
      </h1>
      {subtitle ? <p className="wh-card-title-sub">{subtitle}</p> : null}
      <ArticleProse html={html} />
    </div>
  );
}

function WHStackScreen({ trail, onLink, onReopen, onDeadLink }) {
  const start = Math.max(0, trail.length - VISIBLE_CARDS);
  const visible = trail.slice(start);
  const m = visible.length;

  return (
    <div style={{ flex: 1, position: "relative", overflow: "hidden" }} data-screen-label="Stack">
      {visible.map((entry, j) => {
        const i = start + j; /* index in the full trail */
        const isTop = j === m - 1;
        const data = window.WH_DATA.articles[entry.title] || {};
        const state = isTop ? (entry.loading ? "loading" : "active") : "buried";
        const inset = (m - 1 - j) * 14;
        return (
          <div
            key={entry.title}
            style={{
              position: "absolute",
              top: 6 + j * 40,
              bottom: 0,
              left: "50%",
              transform: "translateX(-50%)",
              width: `min(calc(var(--card-width) - ${inset}px), calc(100% - 64px - ${inset}px))`,
              zIndex: j + 1,
            }}
          >
            <ArticleCard
              index={i + 1}
              title={entry.title}
              subtitle={data.subtitle}
              state={state}
              entering={isTop && entry.entered}
              onTabClick={() => onReopen(i)}
              style={{ height: "100%" }}
            >
              {state === "active" ? (
                <WHArticleContent
                  title={entry.title}
                  subtitle={data.subtitle}
                  html={data.html}
                  isTop={isTop}
                  onLink={onLink}
                  onDeadLink={onDeadLink}
                />
              ) : (
                <div style={{ maxWidth: "var(--measure-prose)", margin: "0 auto" }}>
                  <h1 className="wh-card-title">{entry.title}</h1>
                  {data.subtitle ? <p className="wh-card-title-sub">{data.subtitle}</p> : null}
                </div>
              )}
            </ArticleCard>
          </div>
        );
      })}
    </div>
  );
}

window.WHStackScreen = WHStackScreen;
