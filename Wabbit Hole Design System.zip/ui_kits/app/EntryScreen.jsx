/* Entry screen — shown when no cards are open. */
const { SearchField, Button, Wordmark } = window.WabbitHoleDesignSystem_ca83f3;

function WHEntryScreen({ onOpen, onRandom, onAbout }) {
  const [q, setQ] = React.useState("");
  const results = q.trim()
    ? window.WH_DATA.searchPool.filter((r) => r.title.toLowerCase().startsWith(q.trim().toLowerCase()))
    : [];

  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>
      <main
        style={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          padding: "0 24px 8vh",
        }}
      >
        <Wordmark size="hero" />
        <p
          style={{
            fontFamily: "var(--font-serif)",
            fontSize: "var(--text-lg)",
            color: "var(--text-secondary)",
            margin: "14px 0 40px",
            textAlign: "center",
            maxWidth: 440,
            lineHeight: 1.5,
            textWrap: "balance",
          }}
        >
          Follow one link. Then another. The stack is the story of how you got here.
        </p>
        <div style={{ width: "min(560px, 100%)" }}>
          <SearchField size="lg" value={q} onChange={setQ} results={results} onSelect={(r) => onOpen(r.title)} autoFocus />
        </div>
        <div style={{ marginTop: 20 }}>
          <Button variant="ghost" icon="shuffle" onClick={onRandom}>
            or fall in somewhere random ↓
          </Button>
        </div>
      </main>
      <footer
        style={{
          padding: "16px 24px 20px",
          textAlign: "center",
          fontSize: "var(--text-caption)",
          color: "var(--text-faint)",
        }}
      >
        Article text from{" "}
        <a href="https://en.wikipedia.org" target="_blank" rel="noopener" style={{ color: "var(--text-secondary)" }}>
          Wikipedia
        </a>
        , reformatted, under{" "}
        <a href="https://creativecommons.org/licenses/by-sa/4.0/" target="_blank" rel="noopener" style={{ color: "var(--text-secondary)" }}>
          CC BY-SA 4.0
        </a>
        . Not affiliated with the Wikimedia Foundation. ·{" "}
        <a
          href="#about"
          onClick={(e) => {
            e.preventDefault();
            onAbout();
          }}
          style={{ color: "var(--text-secondary)" }}
        >
          About
        </a>
      </footer>
    </div>
  );
}

window.WHEntryScreen = WHEntryScreen;
