/* Canned article content for the UI kit demo.
   Link grammar inside content HTML:
   - <a data-article="Title">          internal — spawns a card
   - <a class="wh-dead" data-dead>     red link — inert, toast on click
   - <a class="wh-ext" href target>    external — new tab
   - <sup class="wh-ref"><a data-ref="id">  footnote — scrolls within card
   Images are placeholders (.wh-imgph) — the real app lazy-loads from
   Wikipedia's CDN; no imagery is bundled with the design system. */

window.WH_DATA = (() => {
  const articles = {};

  articles["Okapi"] = {
    subtitle: "Species of mammal",
    html: `
      <table class="wh-infobox">
        <caption>Okapi</caption>
        <tbody>
          <tr><td colspan="2"><div class="wh-imgph" style="aspect-ratio: 4 / 3"><span class="wh-icon" data-name="layers"></span></div>
          <div style="font-size: 11.5px; color: var(--text-faint); padding: 4px 2px 0;">Okapi at Epulu Conservation Centre</div></td></tr>
          <tr><td colspan="2" class="wh-infobox-section">Conservation status</td></tr>
          <tr><th>Status</th><td>Endangered <span style="color: var(--text-faint)">(IUCN 3.1)</span><sup class="wh-ref"><a data-ref="okapi-note-1">[1]</a></sup></td></tr>
          <tr><td colspan="2" class="wh-infobox-section">Scientific classification</td></tr>
          <tr><th>Kingdom</th><td><a data-article="Animalia">Animalia</a></td></tr>
          <tr><th>Class</th><td><a data-article="Mammalia">Mammalia</a></td></tr>
          <tr><th>Order</th><td><a data-article="Artiodactyla">Artiodactyla</a></td></tr>
          <tr><th>Family</th><td><a data-article="Giraffidae">Giraffidae</a></td></tr>
          <tr><th>Genus</th><td><i>Okapia</i></td></tr>
          <tr><th>Species</th><td><i>O. johnstoni</i></td></tr>
        </tbody>
      </table>
      <p class="wh-lead">The <b>okapi</b> (<i>Okapia johnstoni</i>) is an artiodactyl mammal that is endemic to the northeast <a data-article="Democratic Republic of the Congo">Democratic Republic of the Congo</a>. It is the only species in the genus <i>Okapia</i>. Although the okapi has striped markings reminiscent of <a data-article="Zebra">zebras</a>, it is most closely related to the <a data-article="Giraffe">giraffe</a>.<sup class="wh-ref"><a data-ref="okapi-note-2">[2]</a></sup></p>
      <p>The okapi stands about 1.5&nbsp;m tall at the shoulder. Its coat is a chocolate to reddish brown, in striking contrast with the white horizontal stripes on the legs and white ankles. Male okapis have short, hair-covered ossicones; females possess hair whorls instead.<sup class="wh-ref"><a data-ref="okapi-note-2">[2]</a></sup></p>
      <h2>Etymology</h2>
      <p>The common name comes from the <a class="wh-dead" data-dead>Lese Karo</a> name <i>o'api</i>, borrowed from the neighbouring Efé peoples of the <a data-article="Ituri Rainforest">Ituri Rainforest</a>. Early European accounts described an "African unicorn"; the species was not described scientifically until 1901.<sup class="wh-ref"><a data-ref="okapi-note-3">[3]</a></sup></p>
      <h2>Behaviour and ecology</h2>
      <p>Okapis are largely diurnal and essentially solitary, coming together only to breed. They are herbivores, feeding on tree leaves and buds, grasses, ferns, fruits, and fungi; over 100 plant species have been recorded in the diet, some of them poisonous to humans.</p>
      <figure>
        <div class="wh-imgph" style="aspect-ratio: 16 / 9"><span class="wh-icon" data-name="layers"></span></div>
        <figcaption>Forest clearing in the Ituri Rainforest, typical okapi habitat. Images load from Wikipedia's CDN and are licensed individually.</figcaption>
      </figure>
      <h2>Status</h2>
      <p>The <a class="wh-ext" href="https://www.iucnredlist.org/" target="_blank" rel="noopener">IUCN Red List</a> classifies the okapi as endangered. Major threats include habitat loss and illegal mining. Population estimates vary considerably by survey area:</p>
      <div class="wh-tablewrap"><table class="wh-table">
        <thead><tr><th>Survey area</th><th>Year</th><th style="text-align: right">Estimate</th><th>Trend</th></tr></thead>
        <tbody>
          <tr><td>Ituri landscape</td><td class="wh-num">2011</td><td class="wh-num">3,500–7,000</td><td>Declining</td></tr>
          <tr><td>Réserve de faune à okapis</td><td class="wh-num">2018</td><td class="wh-num">2,200</td><td>Declining</td></tr>
          <tr><td>Maiko National Park</td><td class="wh-num">2020</td><td class="wh-num">1,800</td><td>Unknown</td></tr>
        </tbody>
      </table></div>
      <h2>References</h2>
      <div class="wh-refs"><ol>
        <li id="okapi-note-1">Mallon, D.; Kümpel, N. (2015). "<i>Okapia johnstoni</i>". IUCN Red List of Threatened Species.</li>
        <li id="okapi-note-2">Bodmer, R.; Rabb, G. (1992). "<i>Okapia johnstoni</i>". Mammalian Species (422): 1–8.</li>
        <li id="okapi-note-3">Johnston, H. (1901). "The okapi: the newly discovered beast". Proceedings of the Zoological Society of London.</li>
      </ol></div>
    `,
  };

  articles["Giraffe"] = {
    subtitle: "Tallest living terrestrial animal",
    html: `
      <p class="wh-lead">The <b>giraffe</b> is a large African hoofed mammal belonging to the genus <i>Giraffa</i>. It is the tallest living terrestrial animal and the largest ruminant on Earth.<sup class="wh-ref"><a data-ref="giraffe-note-1">[1]</a></sup></p>
      <p>The giraffe's chief distinguishing characteristics are its extremely long neck and legs, its horn-like ossicones, and its spotted coat patterns. Its closest living relative is the <a data-article="Okapi">okapi</a>, with which it forms the family <a data-article="Giraffidae">Giraffidae</a>.</p>
      <h2>Habitat</h2>
      <p>Giraffes usually inhabit savannahs and open woodlands, from Chad in the north to South Africa in the south. Large aggregations occur seasonally in the <a data-article="Serengeti">Serengeti</a> and other East African grasslands, where they browse on acacia at heights no other herbivore can reach.</p>
      <figure>
        <div class="wh-imgph" style="aspect-ratio: 3 / 2"><span class="wh-icon" data-name="layers"></span></div>
        <figcaption>Masai giraffe browsing, Serengeti National Park.</figcaption>
      </figure>
      <h2>References</h2>
      <div class="wh-refs"><ol>
        <li id="giraffe-note-1">Dagg, A. I. (2014). <i>Giraffe: Biology, Behaviour and Conservation.</i> Cambridge University Press.</li>
      </ol></div>
    `,
  };

  articles["Serengeti"] = {
    subtitle: "Geographical region in Africa",
    html: `
      <p class="wh-lead">The <b>Serengeti</b> ecosystem is a geographical region in Africa, spanning northern Tanzania and southwestern Kenya. It hosts the largest terrestrial mammal migration in the world.<sup class="wh-ref"><a data-ref="serengeti-note-1">[1]</a></sup></p>
      <p>The name comes from the Maasai word <i>seringit</i>, meaning "endless plains". Over 1.5 million wildebeest and 250,000 zebra cross its plains each year, trailed by predators and, more recently, photographers. The region includes Serengeti National Park and several game reserves, and neighbours the <a class="wh-dead" data-dead>Loliondo Game Controlled Area</a>.</p>
      <p>Its volcanic soils trace to the <a data-article="Ituri Rainforest">highlands</a> to the west and support short sweet grasses that drive the migration's rhythm.</p>
      <h2>References</h2>
      <div class="wh-refs"><ol>
        <li id="serengeti-note-1">Sinclair, A. R. E. (2012). <i>Serengeti Story.</i> Oxford University Press.</li>
      </ol></div>
    `,
  };

  articles["Ituri Rainforest"] = {
    subtitle: "Rainforest in the Congo Basin",
    html: `
      <p class="wh-lead">The <b>Ituri Rainforest</b> is a dense tropical forest in the northeast of the <a data-article="Democratic Republic of the Congo">Democratic Republic of the Congo</a>, named for the Ituri River which flows through it.</p>
      <p>Roughly 63,000&nbsp;km² in extent, the forest shelters the <a data-article="Okapi">okapi</a>, forest elephants, and some of the last old-growth mbau stands in Central Africa. About a fifth of it is protected as the Okapi Wildlife Reserve, a UNESCO World Heritage Site.</p>
    `,
  };

  articles["Democratic Republic of the Congo"] = {
    subtitle: "Country in Central Africa",
    html: `
      <p class="wh-lead">The <b>Democratic Republic of the Congo</b> is a country in Central Africa, the second-largest on the continent. Its rainforests — including the <a data-article="Ituri Rainforest">Ituri</a> — form the heart of the Congo Basin.</p>
      <p>The country spans two time zones and holds most of the Congo River's course, the deepest river on Earth.</p>
    `,
  };

  articles["Giraffidae"] = {
    subtitle: "Family of mammals",
    html: `
      <p class="wh-lead"><b>Giraffidae</b> is a family of ruminant artiodactyl mammals that today contains just two living genera — the <a data-article="Giraffe">giraffe</a> and the <a data-article="Okapi">okapi</a> — the remnant of a lineage once spread across Eurasia and Africa.</p>
      <p>Fossil giraffids such as <i>Sivatherium</i> carried moose-like antlers and stood as tall as elephants at the shoulder.</p>
    `,
  };

  /* Entry-screen autocomplete pool */
  const searchPool = [
    { title: "Okapi", description: "Species of mammal" },
    { title: "Okavango Delta", description: "River delta in Botswana" },
    { title: "Okra", description: "Species of flowering plant" },
    { title: "Oka River", description: "River in central Russia" },
    { title: "Giraffe", description: "Tallest living terrestrial animal" },
    { title: "Giraffidae", description: "Family of mammals" },
    { title: "Serengeti", description: "Geographical region in Africa" },
    { title: "Serendipity", description: "Unplanned fortunate discovery" },
    { title: "Ituri Rainforest", description: "Rainforest in the Congo Basin" },
    { title: "Democratic Republic of the Congo", description: "Country in Central Africa" },
  ];

  /* "fall in somewhere random" pool — articles we actually have */
  const randomPool = ["Okapi", "Giraffe", "Serengeti", "Ituri Rainforest", "Giraffidae"];

  return { articles, searchPool, randomPool };
})();
