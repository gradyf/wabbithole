# Wabbit Hole app UI kit

A clickable recreation of the whole product: entry screen → card stack → trail sidebar → about, with toasts, the duplicate rule, Markdown export, and keyboard flow (Escape = back, arrows/Enter in search).

## Files
- `index.html`: the interactive app shell (start here)
- `EntryScreen.jsx`: wordmark, tagline, search, random, legal footer
- `StackScreen.jsx`: stack geometry (40px tab cascade, 14px width step per depth), link delegation, footnote scroll + flash
- `articles.js`: canned article content (Okapi trail); see its header for the link grammar

## Notes
- Stack geometry lives here, not in the components: `ArticleCard` renders one card; this kit positions up to 5 of them (`VISIBLE_CARDS`).
- The Trail button in the top bar toggles the docked left sidebar (`TrailPanel`), which starts collapsed.
- Images are placeholder blocks (`.wh-imgph`, ruled like blank card stock) by design; the real product lazy-loads from Wikipedia's CDN and ships no imagery.
- Reopening an earlier card dismisses the cards above it (matches product behavior).
- Try: search "oka" → Okapi → click *giraffe* → *Serengeti* → click *Okapi* in the infobox chain (duplicate rule) → Trail → Export Markdown.
